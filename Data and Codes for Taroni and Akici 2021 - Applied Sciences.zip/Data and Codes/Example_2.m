% Example 2: new adaptive smoothed model 

% load the seismic catalog in ZMAP format + the 11-th column with the
% Cluster Number (this number corresponds to the 'vCl' output of the 
% 'calc_decluster' ZMAP function)
Catalog_Raw = load( 'CMT_Catalog_1980_2019_MagnMin55Mw_DepthMax50km_withClusterNumber.txt' ) ;

% time interval for the events in the catalog:
% staring and ending year
StartingY = 2010 ;
EndingY   = 2015 ;

% select the event in the catalog according to starting and ending year
Catalog = Catalog_Raw( Catalog_Raw(:,3) >= StartingY ...
                     & Catalog_Raw(:,3) <= EndingY , : ) ;

% load the spatial grid (in this case 1�x1�)
LongLat = load( 'SpatialGrid_1x1.txt' ) ;

% value for the parameter NN of the smoothing
NN = 4 ;

% compute the smoothing seismicity model
SMOOTH = New_Adaptive_Smoothed_Seismicity( Catalog , NN , LongLat ) ;

% plot the log10-rate of the model
% and add the world coast
scatter( SMOOTH(:,1) , SMOOTH(:,2) , 4 , log10( SMOOTH(:,3) ) , 'filled' )
caxis( [ -4 , -2.5 ] )
colorbar
xlim( [ -180 , 180 ] ) ; xlabel( 'Longitude (�)' )
ylim( [  -90 ,  90 ] ) ; ylabel( 'Latitude (�)'  )
hold on
load coast
plot( long , lat , 'k' )

