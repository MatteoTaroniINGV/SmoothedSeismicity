% Function for New Adaptive Smoothing Seismicity Approach.
% This approach includes a correction for events in a seismic sequence.

% INPUT
%
% CATALOG: a seismic catalog in the following format: ZMAP (1-10th column), 
%          cluster number (from the 'calc_decluster.m' function of the  
%          ZMAP toolbox) (11-th column);
%
% NN: vector (or a single value) for the "number of neighbors" in the
%     adaptive smoothing approach;
%
% LONGLAT: a matrix in the following format: longitude of the center of
%          the i-th spatial cell (1st column), latitude of the center of 
%          the i-th spatial cell (2nd column), area of the i-th spatial
%          cell (the unit of measure is not important) (3rd column);


% OUTPUT
%
% SMOOTH: a matrix in the following format: longtitude of the center of
%          the i-th spatial cell (1st column), latitude of the center of 
%          the i-th spatial cell (2nd column), normalized seismicity rates
%          (3rd-last column, depending on the length of the vector NN)

function SMOOTH = New_Adaptive_Smoothed_Seismicity( Catalog , NN , LongLat )

% preallocation of model matrix
SMOOTH = zeros( size( LongLat , 1 ) , 2 + length( NN ) ) ; 

% assign longitude and latitude
SMOOTH( : , 1 ) = LongLat( : , 1 ) ;    
SMOOTH( : , 2 ) = LongLat( : , 2 ) ;

% computation for each cell in the grid of the smoothed values
for i = 1 : size( Catalog , 1 )
        
        % compute the distance of the i-th event in the catalogue from the
        % center of the all the grid cells
        R = acos(sin(SMOOTH( : , 2 )*pi/180).* sin(Catalog( i , 2 )*pi/180) + cos(SMOOTH( : , 2 )*pi/180).*...
            cos(Catalog( i , 2 )*pi/180).* cos((Catalog( i , 1 ) - SMOOTH( : , 1 ))*pi/180))*6371;
        
        % compute the distance of each event in the catalogue from the
        % i-th event (including himself, then that distance is zero)
        Dist = acos(sin(Catalog( : , 2 )*pi/180).* sin(Catalog( i , 2 )*pi/180) + cos(Catalog( : , 2 )*pi/180).*...
               cos(Catalog( i , 2 )*pi/180).* cos((Catalog( i , 1 ) - Catalog( : , 1 ))*pi/180))*6371;
        
        % sort the distances
        Sorted_Dist = sort( Dist ) ;
        
        % if the events is a part of a cluster
        if Catalog( i , 11 ) > 0
            
            % compute the number of events in the cluster
            Num_Events_Cluster = sum( Catalog( : , 11 ) == Catalog( i , 11 ) ) ;
        
        else
            
            % if there is only one event in the cluster
            Num_Events_Cluster = 1 ;
            
        end
        
        
        % correction for the number of events in the cluster
        W_Cluster = 1 / Num_Events_Cluster ;
        
        
        % loop 'for' for the different values of NN
        for j = 1 : length( NN )
        
            % take the distance equal to the maximum between the NN-th 
            % neighbor and a minimum imposed distance (here 44 Km);
            % to compute the NN-th neighbor distance we use 'NN+1', because in
            % the 'Dist' vector is also included the distance=0 between the
            % i-th event with himself
            Sigma = max( [ Sorted_Dist( NN( j ) + 1 ) , 44 ] ) ;
        
            % compute the weights proportional to the Gaussian kernel
            W_Kernel = 1/(2*pi*Sigma^2)*exp((-R.^2)/(2*Sigma^2)); 
        
            % add the total weight of the i-th earthquake to all the spatial cells
            SMOOTH( : , 2 + j ) = SMOOTH( : , 2 + j ) + W_Kernel*W_Cluster ;    
        
        end
        
        % show the remaining number of iterations
        size( Catalog , 1 ) - i 
end


% normalize the rates, also according to the area of each spatial cell
for j = 1 : length( NN )
    
    % area normalization
    SMOOTH( : , 2 + j ) = SMOOTH( : , 2 + j ).*LongLat( : , 3 ) ;
    
    % normalization to 1
    SMOOTH( : , 2 + j ) = SMOOTH( : , 2 + j ) / sum( SMOOTH( : , 2 + j ) ) ;

end

